/**
Language SQL
version 10.1.38
**/

/* A */
update event 
set total_tickets = total_tickets + 100,
	available_tickets = available_tickets + 100,
where id = 1;

update ticket
set total_tickets = total_tickets + 100,
	available_tickets = available_tickets + 100,
where type = 'Adult';
	
/* B */
insert into booking(creation_time, ticket_type, ticket_number, payment_option, delivery_option, status, total_price, discount_id)
values(now(),'Adult',2,'Credit Card','Email','Paid', 20.00*(select 1-discount from discount where id=1), 1);

insert into booking(creation_time, ticket_type, ticket_number, payment_option, delivery_option, status, total_price, discount_id)
values(now(),'Child',1,'Credit Card','Email','Paid', 10.00*(select 1-discount from discount where id=1), 1);

insert into customer(fname, lname, address_1, city, postcode, Tel_number, Email, Age, booking_ref)
values('Ian', 'Cooper', '14 Box Close', 'Exeter', 'EX4 1QD', 07789364716, 'iancooper51@gmail.com', 41, 7);

insert into payment_info(customer_id, card_number, expiry_date, security_code)
values(4, 4567945623485673, '2022-09-01', 691);

insert into payment(booking_id, payment_info_id, payment_method, total, payment_time, discount_id)
values(7, 4, 'Credit Card', 26.00*(select 1-discount from discount where id=1), now(), 1);

update event
set available_tickets = available_tickets - 3
where id = 1;

update ticket
set available_tickets = available_tickets - 2
where type = 'Adult';

update ticket
set available_tickets = available_tickets -1
where type = 'Child';

/* C */
set @booking2 = 3;
update payment
inner join booking
on payment.booking_id = booking.reference
inner join ticket
on booking.ticket_type = ticket.type
inner join event
on ticket.event = event.id
set payment.refund_needed = '1'
where now() <= event.start and booking.reference = @booking2;

update booking
inner join ticket
on booking.ticket_type = ticket.type
inner join event
on ticket.event = event.id
set booking.status = 'Refund started'
where now() <= event.start and booking.reference = @booking2;

/* D */
insert into discount(event, code, discount)
values(4, 'SUMMER20', 0.2);