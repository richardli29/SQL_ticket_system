/**
Language SQL
version 10.1.38
**/

/* A */ 
select type, count(*) as 'event'
from ticket
where event=1 group by type;

/* B */
select * from event
where 
start >= '2020-07-01' and end <= '2020-07-10';

/* C */
select type, available_tickets, price
from ticket
where 
event=2 group by type
and type='Bronze';

/* D */
select customer.name, booking.ticket_type, booking.ticket_number
from customer
inner join booking
on customer.booking_ref = booking.reference
where booking.ticket_type= 'Gold';

/* E */
select customer.name, event.name
from customer
inner join booking
on customer.booking_ref = booking.reference
inner join ticket
on booking.ticket_type = ticket.type
inner join event
on ticket.event = event.id
where booking.creation_time >= now() - interval 7 day;

/* F */
select * from event
order by (total_tickets - available_tickets) desc;

/* G */
set @booking1 = 1;
select customer.name, event.name, customer.booking_ref, booking.creation_time, booking.delivery_option, booking.payment_option, booking.ticket_number, booking.total_price
from customer
inner join booking
on customer.booking_ref = booking.reference
inner join ticket
on booking.ticket_type = ticket.type
inner join event
on ticket.event = event.id
where booking_ref= @booking1;

/* H */
select event.name, sum(booking.total_price) as 'total revenue'
from booking
inner join ticket
on booking.ticket_type = ticket.type
inner join event
on ticket.event = event.id
group by event.name;