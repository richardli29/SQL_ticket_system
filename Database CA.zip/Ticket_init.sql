/**
Language SQL
version 10.1.38
**/

drop database if exists events;
create database events;
use events;

create table event(
	id int auto_increment primary key not null,
	name varchar(255) not null,
	total_tickets int(10) not null,
	available_tickets int(10) not null,
	description varchar(255) not null,
	start datetime,
	end datetime,
	address_1 varchar(255) not null,
	address_2 varchar(255),
	city varchar(255) not null,
	postcode varchar(11) not null,
	Location varchar(255) as (concat_ws(', ', address_1, address_2, city, postcode))
);


insert into event(name, total_tickets, available_tickets, description, start, end, address_1, city, postcode)
values(
	'Bristol food festival', 
	100, 
	98,
	'Bristol\'s best and only food festival for all ages', 
	'2020-06-18 10:00:00', 
	'2020-06-18 20:00:00', 
	'25 Glass House Ln', 
	'Bristol', 
	'BS1 3BX'
);

insert into event(name, total_tickets, available_tickets, description, start, end, address_1, city, postcode)
values(
	'Bristol christmas festival', 
	200, 
	200,
	'Bristols christmas festival with market for all ages', 
	'2020-07-03 10:00:00', 
	'2020-07-03 20:00:00', 
	'Castle Park', 
	'Bristol', 
	'BS1 2XD'
);

insert into event(name, total_tickets, available_tickets, description, start, end, address_1, city, postcode)
values(
	'Hippodrome drama', 
	100, 
	100,
	'Bristols hippodrome musical for all ages', 
	'2020-07-07 16:00:00', 
	'2020-07-07 20:00:00', 
	'St Augustine\'s Parade', 
	'Bristol', 
	'BS1 4UZ'
);

insert into event(name, total_tickets, available_tickets, description, start, end, address_1, city, postcode)
values(
	'Keynsham music festival',
	100,
	95,
	'This event will feature areas like musical genres and arts: delicious food, real ales, stalls and creative activities for all to enjoy.',
	'2020-06-18 10:00:00',
	'2020-06-24 18:00:00',
	'Temple St', 'Bristol',
	'BS31 1HE'
);

create table ticket(
	id int auto_increment primary key,
    event int not null,
	type varchar(255) not null unique,
	description varchar(255),
	price decimal(10, 2) not null,
	total_tickets int(10) not null,
	available_tickets int(10) not null,
    foreign key(event) references event(id)
);

insert into ticket(event, type, description, total_tickets, available_tickets, price)
values(1, 'Adult', '15 years or up', 50, 49, 10.00);

insert into ticket(event, type, description, total_tickets, available_tickets, price)
values(1, 'Child', '5 to 14 years old', 50, 49, 6.00);

insert into ticket(event, type, description, total_tickets, available_tickets, price)
values(2, 'Bronze', 'Bronze low tier ticket', 50, 49, 10.00);

insert into ticket(event, type, description, total_tickets, available_tickets, price)
values(2, 'Silver', 'Silver mid tier ticket', 30, 29, 18.00);

insert into ticket(event, type, description, total_tickets, available_tickets, price)
values(2, 'Gold', 'Gold top tier ticket', 20, 17, 25.00);

create table discount( 
	id int auto_increment primary key,   
	event int not null,  
	code varchar(255),
	discount decimal(4, 2),  
	foreign key(event) references event(id)	  
);

insert into discount(event, code, discount)
values(1, 'FOOD10', 0.1);

create table booking(
	reference int auto_increment primary key,
	creation_time datetime not null,
	ticket_type varchar(255),
	ticket_number int(10),
	total_price decimal(10,2) not null,
	payment_option varchar(15),
	delivery_option varchar(20),
	status varchar(30),
	discount_id int,
	foreign key(ticket_type) references ticket(type),
	foreign key(discount_id) references discount(id)
);
	
insert into booking(creation_time, ticket_type, ticket_number, payment_option, delivery_option, status, total_price, discount_id)
values(now(),'Adult',1,'VISA','Email','Paid', 10.00, 1);

insert into booking(creation_time, ticket_type, ticket_number, payment_option, delivery_option, status, total_price)
values(now(),'Child',1,'VISA','Email','Paid', 6.00);

insert into booking(creation_time, ticket_type, ticket_number, payment_option, delivery_option, status, total_price)
values(now(),'Bronze',1,'Mastercard','Email','Paid', 10.00);

insert into booking(creation_time, ticket_type, ticket_number, payment_option, delivery_option, status, total_price)
values(now(),'Silver',1,'VISA','Email','Paid', 18.00);

insert into booking(creation_time, ticket_type, ticket_number, payment_option, delivery_option, status, total_price)
values(now(),'Gold',2,'VISA','Email','Paid', 50.00);

insert into booking(creation_time, ticket_type, ticket_number, payment_option, delivery_option, status, total_price)
values(now(),'Gold',1,'VISA','Email','Paid', 25.00);
	
create table customer(
	id int auto_increment primary key,
	booking_ref int not null,
	fname varchar(255) not null,
	lname varchar(255) not null,
	address_1 varchar(255) not null,
	address_2 varchar(255),
	city varchar(255) not null,
	postcode varchar(11) not null,
	Tel_number varchar(16) not null,
	Email varchar(255) not null,
	Age int(3),
	name varchar(255) as (concat_ws(' ', fname, lname)),
	address varchar(255) as (concat_ws(', ', address_1, address_2, city, postcode)),
	foreign key(booking_ref) references booking(reference)
);

insert into customer(fname, lname, address_1, city, postcode, Tel_number, Email, Age, booking_ref)
values('John', 'Petterson', '14 Chapel Close', 'Exeter', 'EX4 2JZ', 07789281928, 'johnpetterson14@gmail.com', 41, 1);

insert into customer(fname, lname, address_1, city, postcode, Tel_number, Email, Age, booking_ref)
values('Sally', 'Petterson', '14 Chapel Close', 'Exeter', 'EX4 2JZ', 07789281928, 'johnpetterson14@gmail.com', 13, 2);

insert into customer(fname, lname, address_1, city, postcode, Tel_number, Email, Age, booking_ref)
values('Joe', 'Smiths', '1 Chanel Close', 'Exeter', 'EX1 4EA', 07726186928, 'joesmiths13@gmail.com', 25, 3);

insert into customer(fname, lname, address_1, city, postcode, Tel_number, Email, Age, booking_ref)
values('James', 'Philip', '214 Cowley Road', 'Exeter', 'EX4 4DJ', 07786905928, 'jamesphil12@gmail.com', 23, 4);

insert into customer(fname, lname, address_1, city, postcode, Tel_number, Email, Age, booking_ref)
values('Lewis', 'Guy', '62 Haldon Close', 'Exeter', 'EX4 4DP', 07792758281, 'lewisguy109@gmail.com', 23, 5);

insert into customer(fname, lname, address_1, city, postcode, Tel_number, Email, Age, booking_ref)
values('Dan', 'Bond', '24 New Road', 'Exeter', 'EX1 4EF', 07795946987, 'lewisguy109@gmail.com', 23, 6);

create table payment_info(
	id int auto_increment primary key,
	customer_id int not null,
	card_number varchar(16) not null,
	expiry_date date not null,
	security_code varchar(3) not null,
	foreign key(customer_id) references customer(id)
);
	
insert into payment_info(customer_id, card_number, expiry_date, security_code)
values(1, 4695829596026572, '2022-12-01', 981);

insert into payment_info(customer_id, card_number, expiry_date, security_code)
values(2, 4695829596026572, '2022-12-01', 981);

insert into payment_info(customer_id, card_number, expiry_date, security_code)
values(3, 4539462194125896, '2021-08-01', 792);
	
create table payment(
	id int auto_increment primary key,
	booking_id int not null,
	payment_info_id int not null,
	payment_method varchar(255) not null,
	total decimal(10,2) not null,
	payment_time datetime not null,
	refund_needed boolean default 0,
	discount_id int,
	foreign key(booking_id) references booking(reference),
	foreign key(payment_info_id) references payment_info(id),
	foreign key(discount_id) references discount(id)
);

insert into payment(booking_id, payment_info_id, payment_method, total, payment_time, discount_id)
values(1, 1, 'VISA', 10.00, now(), 1);

insert into payment(booking_id, payment_info_id, payment_method, total, payment_time)
values(2, 2, 'VISA', 6.00, now());

insert into payment(booking_id, payment_info_id, payment_method, total, payment_time)
values(3, 3, 'Master Card', 10.00, now());

